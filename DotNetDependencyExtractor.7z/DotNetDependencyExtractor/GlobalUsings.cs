﻿global using System;
global using Mono.Cecil;
global using Mono.Cecil.Cil;
global using static DotNetDependencyExtractor.FileHelper;
global using static DotNetDependencyExtractor.CecilHelper;